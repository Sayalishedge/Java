package CustomException;

public class customException extends Exception{
	public customException(String msg) {
		
		super(msg);
	}

}
