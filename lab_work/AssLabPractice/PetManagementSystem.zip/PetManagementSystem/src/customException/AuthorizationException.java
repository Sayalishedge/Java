package customException;

public class AuthorizationException extends Exception{
	public AuthorizationException(String msg) {
		super(msg);
		
		
	}

}
