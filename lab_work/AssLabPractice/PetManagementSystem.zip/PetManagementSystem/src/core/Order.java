package core;

import java.util.HashMap;

public class Order {
	public static int orderId =1;
	public int petId;
	public int quantity;
	public Status status;
	
	public Order(int petId, int quantity, Status status) {
		super();
		this.orderId = orderId++;
		this.petId = petId;
		this.quantity = quantity;
		this.status = status;
	}
	public Order(int oId, HashMap<Integer, Order> orderHmap) {
		// TODO Auto-generated constructor stub
	}


	
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + "petId=" + petId + ", quantity=" + quantity + ", status=" + status + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	
	public static void setOrderId(int orderId) {
		Order.orderId = orderId;
	}

	public Integer getOrderId() {
		// TODO Auto-generated method stub
		return orderId;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	
	
	
	
	
	

}
