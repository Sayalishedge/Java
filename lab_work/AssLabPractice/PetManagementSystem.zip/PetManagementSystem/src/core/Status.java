package core;

public enum Status {
	PLACED,IN_PROGRESS,COMPLETED;

}
