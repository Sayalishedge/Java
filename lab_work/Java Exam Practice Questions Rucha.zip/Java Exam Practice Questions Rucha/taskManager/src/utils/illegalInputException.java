package utils;

public class illegalInputException extends Exception{
	public illegalInputException(String msg) {
		super(msg);
	}
}
