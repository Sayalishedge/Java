package core;

public enum Status {
	PENDING,INPROGRESS,COMPLETED
}
