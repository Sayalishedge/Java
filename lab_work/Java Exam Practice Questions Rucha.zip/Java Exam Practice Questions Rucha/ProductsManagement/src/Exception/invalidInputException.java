package Exception;

public class invalidInputException extends Exception{
	public invalidInputException(String msg) {
		super(msg);
	}
}
